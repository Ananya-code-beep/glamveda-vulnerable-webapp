-- GlamVeda schema and seed data
-- Run: mysql -u root -proot < sql/schema.sql

DROP DATABASE IF EXISTS glamveda;
CREATE DATABASE glamveda;
USE glamveda;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL,
    email VARCHAR(150),
    role VARCHAR(20) DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    category VARCHAR(50),
    price DECIMAL(10,2),
    description TEXT,
    image VARCHAR(255)
);

CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    username VARCHAR(100),
    review_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    product_id INT,
    quantity INT,
    total DECIMAL(10,2),
    shipping_address VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(150),
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed users (plaintext passwords intentionally, for lab demo of the auth-bypass vuln)
INSERT INTO users (username, password, email, role) VALUES
('admin', 'AdminP@ss123', 'admin@glamveda.local', 'admin'),
('priya', 'priya123', 'priya@example.com', 'customer'),
('ananya', 'ananya123', 'ananya@example.com', 'customer'),
('testuser', 'password', 'testuser@example.com', 'customer');

-- Seed products
INSERT INTO products (name, category, price, description, image) VALUES
('Rose Glow Face Serum', 'skincare', 799.00, 'Hydrating serum with rose extract.', 'serum.png'),
('Matte Lipstick - Coral', 'makeup', 349.00, 'Long-lasting matte finish.', 'lipstick.png'),
('Herbal Shampoo 200ml', 'haircare', 299.00, 'Sulfate-free herbal shampoo.', 'shampoo.png'),
('Charcoal Face Wash', 'skincare', 249.00, 'Deep cleansing charcoal formula.', 'facewash.png'),
('Kajal Pencil - Black', 'makeup', 149.00, 'Smudge-proof kajal.', 'kajal.png');

-- Seed orders (across different users, for IDOR demo)
INSERT INTO orders (user_id, product_id, quantity, total, shipping_address) VALUES
(2, 1, 2, 1598.00, '12 MG Road, Kochi, Kerala'),
(3, 2, 1, 349.00, '45 Beach Road, Kannur, Kerala'),
(4, 3, 3, 897.00, '9 Lake View, Chennai, Tamil Nadu');

-- Seed a couple of reviews and contact messages (clean, non-payload examples)
INSERT INTO reviews (product_id, username, review_text) VALUES
(1, 'priya', 'Really loved this serum, great for dry skin!'),
(2, 'ananya', 'Color payoff is amazing for the price.');

INSERT INTO contact_messages (name, email, message) VALUES
('Priya S', 'priya@example.com', 'When will the Rose Glow serum restock in the 100ml size?');
