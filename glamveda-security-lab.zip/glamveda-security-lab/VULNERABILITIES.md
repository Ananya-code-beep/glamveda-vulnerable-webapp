# Vulnerability Report — GlamVeda

Matches the actual project README exactly — same endpoints, same payloads, same hints.

---

## 1. SQL Injection — Authentication Bypass — High
**CWE-89** | `/login.php`
- **PoC:** `admin' OR '1'='1' -- -` as username
- **Impact:** Full auth bypass
- **Fix:** Parameterized queries (`bind_param`)

## 2. SQL Injection — UNION-based Extraction — High
**CWE-89** | `/product.php?id=`
- **PoC:** `1 UNION SELECT 1,username,password,email,1,1,1,1 FROM users`
- **Impact:** Full extraction of the users table
- **Fix:** Parameterized queries; cast `id` to int

## 3. SQL Injection — Search LIKE Injection — High
**CWE-89** | `/search.php?q=`
- **PoC:** `' UNION SELECT ...`
- **Impact:** Data extraction via search field
- **Fix:** Parameterized queries

## 4. SQL Injection — Category Filter — Medium/High
**CWE-89** | `/products.php?category=`
- **PoC:** `1 OR 1=1`
- **Impact:** Bypasses category filter, exposes full product listing regardless of intended scope
- **Fix:** Cast to int, parameterized queries

## 5. Reflected XSS — Medium
**CWE-79** | `/search.php?q=`
- **PoC:** `<script>alert(1)</script>`
- **Impact:** Requires victim to click a crafted link; executes in their session
- **Fix:** `htmlspecialchars()` on reflected output

## 6. Stored XSS — Product Review — Medium-High
**CWE-79** | Product review form on `/product.php`
- **PoC:** `<script>alert(document.cookie)</script>` as a comment
- **Impact:** Persistent, fires for every visitor viewing the product
- **Fix:** Output encoding + CSP

## 7. Stored XSS — Contact Form → Admin Dashboard — High
**CWE-79** | `/contact.php` message, rendered in `/admin/dashboard.php`
- **PoC:** Same script payload, higher-impact target
- **Impact:** Specifically targets admin session — highest-severity XSS in the app
- **Fix:** Output encoding + CSP

## 8. Stored XSS — Username Field — Medium-High
**CWE-79** | `/register.php` username field, fires site-wide in the header once logged in
- **PoC:** Script tag as username
- **Impact:** Broadest passive exposure of the four XSS instances
- **Fix:** Output encoding + CSP

## 9. NoSQL Injection — High
**CWE-943** | `support.php` → Node API `/api/tickets/search`
- **PoC:** `{"email":{"$ne":null},"pin":{"$ne":null}}`
- **Impact:** Bypasses PIN-based ticket lookup, exposes any ticket
- **Fix:** Type-check fields before querying (`typeof === 'string'`)

## 10. IDOR — High
**CWE-639** | `/order.php?id=`
- **PoC:** Increment/decrement `id` while logged in as a different user
- **Impact:** Horizontal privilege escalation across all customer orders
- **Fix:** Add `user_id` ownership check to the query itself

## 11. Command Injection — Critical
**CWE-78** | `/admin/image_tool.php` filename field
- **PoC:** `placeholder.png; id`
- **Impact:** Remote Code Execution as the web server user
- **Fix:** Avoid shell_exec; if unavoidable, `escapeshellarg()` + strict filename validation

## 12. Unrestricted File Upload — Critical
**CWE-434** | `/profile.php` avatar upload
- **PoC:** Upload `shell.php` containing `<?php system($_GET['cmd']); ?>`, then request `/uploads/shell.php?cmd=id`
- **Impact:** Unauthenticated webshell → full RCE
- **Fix:** MIME-type validation via `finfo`, random filenames, disable PHP execution in uploads directory

## 13. CSRF — Checkout — Medium
**CWE-352** | `/checkout.php`
- **PoC:** Auto-submitting cross-origin form places an order as the victim
- **Impact:** Unwanted orders placed without consent (lower severity than an account-takeover CSRF chain)
- **Fix:** Per-session CSRF token validated with `hash_equals()`

---

## Severity Summary

| Severity | Findings |
|---|---|
| Critical | Command Injection, Unrestricted File Upload |
| High | SQLi (4 variants), IDOR, NoSQL Injection, Stored XSS (contact→admin) |
| Medium-High | Stored XSS (review, username) |
| Medium | Reflected XSS, CSRF |

## Tools Used Per Finding

| Tool | Used For |
|---|---|
| sqlmap | Automating SQLi variants #1–4 |
| Burp Suite | XSS/CSRF payload crafting, IDOR repeat testing |
| OWASP ZAP | Baseline automated scan |
| curl / Postman | Manual NoSQLi JSON payloads against the ticket API |
| nikto | Server fingerprinting, catching misconfig (e.g. AllowOverride All) |
