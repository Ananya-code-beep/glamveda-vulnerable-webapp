<?php
// admin/dashboard.php
// VULNERABILITY: Stored XSS sink — renders contact_messages.message unescaped (CWE-79)
// This is the highest-impact XSS in the app because it specifically targets
// whichever admin views this page (session/cookie theft against a privileged account).
session_start();
require '../db.php';

if (($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: ../login.php");
    exit;
}

include '../header.php';

$messages = mysqli_query($conn, "SELECT name, email, message, created_at FROM contact_messages ORDER BY created_at DESC");
$orders = mysqli_query($conn, "SELECT o.id, u.username, p.name AS product_name, o.total FROM orders o
                                JOIN users u ON o.user_id = u.id
                                JOIN products p ON o.product_id = p.id");
?>
<!DOCTYPE html>
<html>
<head><title>Admin Dashboard — GlamVeda</title></head>
<body>
    <h2>Admin Dashboard</h2>

    <h3>Contact Messages</h3>
    <?php while ($m = mysqli_fetch_assoc($messages)): ?>
        <div style="border:1px solid #ccc; padding:8px; margin-bottom:6px;">
            <strong><?= htmlspecialchars($m['name']) ?></strong> (<?= htmlspecialchars($m['email']) ?>)<br>
            <!-- VULNERABLE: message rendered without htmlspecialchars() -->
            <?php echo $m['message']; ?>
        </div>
    <?php endwhile; ?>

    <h3>All Orders</h3>
    <table border="1" cellpadding="5">
        <tr><th>Order ID</th><th>User</th><th>Product</th><th>Total</th></tr>
        <?php while ($o = mysqli_fetch_assoc($orders)): ?>
        <tr>
            <td><?= htmlspecialchars($o['id']) ?></td>
            <td><?= htmlspecialchars($o['username']) ?></td>
            <td><?= htmlspecialchars($o['product_name']) ?></td>
            <td>Rs. <?= htmlspecialchars($o['total']) ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <p><a href="image_tool.php">Image Resize Tool</a></p>
</body>
</html>
