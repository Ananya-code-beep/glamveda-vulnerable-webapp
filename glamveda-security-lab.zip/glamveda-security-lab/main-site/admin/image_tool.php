<?php
// admin/image_tool.php
// VULNERABILITY: Command Injection (CWE-78)
// PoC: filename = placeholder.png; id
// The semicolon terminates the intended `convert` command and chains a second
// command. In a real attack this would be a reverse shell payload instead of `id`.
session_start();

if (($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: ../login.php");
    exit;
}

include '../header.php';

$output = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filename = $_POST['filename']; // VULNERABLE: no validation, no escaping

    // VULNERABLE: user input concatenated directly into a shell command
    $cmd = "convert ../uploads/" . $filename . " -resize 200x200 ../uploads/resized_" . $filename;
    $output = shell_exec($cmd . " 2>&1");
}
?>
<!DOCTYPE html>
<html>
<head><title>Image Resize Tool — GlamVeda Admin</title></head>
<body>
    <h2>Admin: Resize Product/Avatar Image</h2>
    <form method="POST">
        <label>Filename (must already exist in uploads/):</label>
        <input type="text" name="filename" placeholder="placeholder.png" required><br>
        <button type="submit">Resize to 200x200</button>
    </form>

    <?php if ($output !== ''): ?>
        <h3>Output:</h3>
        <pre><?php echo $output; ?></pre>
        <!-- VULNERABLE: command output echoed unescaped -->
    <?php endif; ?>
</body>
</html>
