<?php
// checkout.php
// VULNERABILITY: CSRF — no anti-CSRF token on the order-placement form (CWE-352)
// PoC: host an auto-submitting cross-origin form targeting this endpoint with a
// chosen product_id/quantity; if a logged-in victim visits it, an order is placed
// on their account without consent.
session_start();
require 'db.php';
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // VULNERABLE: no CSRF token check — action performed based solely on session cookie
    $productId = (int) $_POST['product_id'];
    $quantity = (int) $_POST['quantity'];

    $priceResult = mysqli_query($conn, "SELECT price FROM products WHERE id = $productId");
    if ($priceRow = mysqli_fetch_assoc($priceResult)) {
        $total = $priceRow['price'] * $quantity;
        $stmt = $conn->prepare("INSERT INTO orders (user_id, product_id, quantity, total, shipping_address) VALUES (?, ?, ?, ?, 'Default address on file')");
        $stmt->bind_param("iiid", $_SESSION['user_id'], $productId, $quantity, $total);
        $stmt->execute();
        $message = "Order placed successfully!";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Checkout — GlamVeda</title></head>
<body>
    <h2>Checkout</h2>
    <?php if ($message): ?><p><?= htmlspecialchars($message) ?></p><?php endif; ?>

    <!-- No CSRF token hidden field present -->
    <form method="POST">
        <label>Product ID:</label>
        <input type="number" name="product_id" value="1" required><br>
        <label>Quantity:</label>
        <input type="number" name="quantity" value="1" required><br>
        <button type="submit">Place Order</button>
    </form>
</body>
</html>
