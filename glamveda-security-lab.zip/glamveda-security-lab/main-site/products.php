<?php
// products.php
// VULNERABILITY: SQL Injection — category filter (CWE-89)
// PoC: /products.php?category=1 OR 1=1
session_start();
require 'db.php';
include 'header.php';

$category = $_GET['category'] ?? '';

if ($category !== '') {
    // VULNERABLE: raw concatenation, no cast/validation, even though this looks like
    // a simple filter field
    $query = "SELECT id, name, category, price, image FROM products WHERE category = '$category'";
} else {
    $query = "SELECT id, name, category, price, image FROM products";
}

$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html>
<head><title>Products — GlamVeda</title></head>
<body>
    <h2>All Products</h2>
    <form method="GET">
        <select name="category" onchange="this.form.submit()">
            <option value="">All Categories</option>
            <option value="skincare">Skincare</option>
            <option value="makeup">Makeup</option>
            <option value="haircare">Haircare</option>
        </select>
    </form>

    <ul>
    <?php if ($result): while ($row = mysqli_fetch_assoc($result)): ?>
        <li>
            <a href="product.php?id=<?= $row['id'] ?>"><?= htmlspecialchars($row['name']) ?></a>
            — Rs. <?= htmlspecialchars($row['price']) ?> (<?= htmlspecialchars($row['category']) ?>)
        </li>
    <?php endwhile; endif; ?>
    </ul>
</body>
</html>
