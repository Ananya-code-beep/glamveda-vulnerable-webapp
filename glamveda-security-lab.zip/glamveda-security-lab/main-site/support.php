<?php
// support.php
// This page just forwards the ticket lookup form to the Node/Express/MongoDB
// microservice (nosql-api/server.js) running on port 5000.
// VULNERABILITY (NoSQL Injection) lives in that microservice's /api/tickets/search
// endpoint — see nosql-api/server.js for the vulnerable code and PoC.
session_start();
include 'header.php';
?>
<!DOCTYPE html>
<html>
<head><title>Support Tickets — GlamVeda</title></head>
<body>
    <h2>Look Up Your Support Ticket</h2>
    <p>Enter the email and PIN you used when submitting your ticket.</p>

    <form id="ticketForm">
        <input type="email" id="email" placeholder="Email" required><br>
        <input type="text" id="pin" placeholder="PIN" required><br>
        <button type="submit">Look Up Ticket</button>
    </form>

    <pre id="result"></pre>

    <script>
    document.getElementById('ticketForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const pin = document.getElementById('pin').value;

        // Forwards straight to the Node microservice — this is the vulnerable call.
        // A normal user submits real strings here. An attacker can bypass this UI
        // entirely and POST a JSON object with operators (see nosql-api/server.js).
        const res = await fetch('http://localhost:5000/api/tickets/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, pin })
        });
        const data = await res.json();
        document.getElementById('result').textContent = JSON.stringify(data, null, 2);
    });
    </script>
</body>
</html>
