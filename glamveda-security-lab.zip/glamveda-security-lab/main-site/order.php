<?php
// order.php
// VULNERABILITY: IDOR — Insecure Direct Object Reference (CWE-639)
// PoC: while logged in, increment/decrement ?id= to view another user's order.
// No check that the order's user_id matches the logged-in session user.
session_start();
require 'db.php';
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$orderId = $_GET['id'] ?? '1';

// VULNERABLE: no "AND user_id = {$_SESSION['user_id']}" ownership check
$query = "SELECT o.*, p.name AS product_name FROM orders o
          JOIN products p ON o.product_id = p.id
          WHERE o.id = $orderId";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html>
<head><title>Order Details — GlamVeda</title></head>
<body>
    <h2>Order Details</h2>
    <?php if ($result && $row = mysqli_fetch_assoc($result)): ?>
        <p>Order #<?= htmlspecialchars($row['id']) ?></p>
        <p>Product: <?= htmlspecialchars($row['product_name']) ?></p>
        <p>Quantity: <?= htmlspecialchars($row['quantity']) ?></p>
        <p>Total: Rs. <?= htmlspecialchars($row['total']) ?></p>
        <p>Shipping Address: <?= htmlspecialchars($row['shipping_address']) ?></p>
        <!-- Note: shipping_address belongs to whoever placed order #id — not
             necessarily the logged-in user. That's the IDOR. -->
    <?php else: ?>
        <p>Order not found.</p>
    <?php endif; ?>

    <p><a href="?id=<?= (int)$orderId + 1 ?>">Next Order &raquo;</a></p>
</body>
</html>
