<?php
// register.php
// VULNERABILITY: Stored XSS via username field (CWE-79)
// PoC: register with username = <script>alert(document.cookie)</script>
// The username is later rendered unescaped in the site header on every page (see header.php)
session_start();
require 'db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];   // VULNERABLE: not sanitized before storage or output
    $password = $_POST['password'];
    $email = $_POST['email'];

    $stmt = $conn->prepare("INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, 'customer')");
    $stmt->bind_param("sss", $username, $password, $email);

    if ($stmt->execute()) {
        header("Location: login.php");
        exit;
    } else {
        $error = "Registration failed. Username may already exist.";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Register — GlamVeda</title></head>
<body>
    <h2>Create an Account</h2>
    <?php if ($error): ?><p style="color:red;"><?= htmlspecialchars($error) ?></p><?php endif; ?>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <button type="submit">Register</button>
    </form>
</body>
</html>
