<?php
// search.php
// VULNERABILITY 1: SQL Injection — search LIKE injection (CWE-89)
// PoC: /search.php?q=' UNION SELECT 1,username,password,email,1,1,1,1 FROM users -- -
// VULNERABILITY 2: Reflected XSS (CWE-79)
// PoC: /search.php?q=<script>alert(1)</script>
session_start();
require 'db.php';
include 'header.php';

$q = $_GET['q'] ?? '';
$results = [];

if ($q !== '') {
    // VULNERABLE: raw concatenation into a LIKE clause, no parameterization
    $query = "SELECT id, name, price, image FROM products WHERE name LIKE '%$q%'";
    $result = mysqli_query($conn, $query);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $results[] = $row;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Search — GlamVeda</title></head>
<body>
    <h2>Search Products</h2>
    <form method="GET">
        <input type="text" name="q" value="<?= $q ?>" placeholder="Search products...">
        <!-- VULNERABLE: $q echoed back into the value attribute unescaped -->
        <button type="submit">Search</button>
    </form>

    <!-- VULNERABLE: reflects the raw query term directly into the page -->
    <?php if ($q !== ''): ?>
        <p>Results for: <?php echo $q; ?></p>
    <?php endif; ?>

    <ul>
    <?php foreach ($results as $r): ?>
        <li><?= htmlspecialchars($r['name']) ?> — Rs. <?= htmlspecialchars($r['price']) ?></li>
    <?php endforeach; ?>
    </ul>
</body>
</html>
