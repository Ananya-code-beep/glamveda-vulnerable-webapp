<?php
session_start();
require 'db.php';
include 'header.php';

$products = mysqli_query($conn, "SELECT id, name, price, category, image FROM products LIMIT 6");
?>
<!DOCTYPE html>
<html>
<head><title>GlamVeda — Cosmetics Store</title></head>
<body>
    <h1>Welcome to GlamVeda</h1>
    <p>Your one-stop shop for skincare, makeup, and haircare.</p>

    <h2>Featured Products</h2>
    <ul>
    <?php while ($p = mysqli_fetch_assoc($products)): ?>
        <li>
            <a href="product.php?id=<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?></a>
            — Rs. <?= htmlspecialchars($p['price']) ?>
        </li>
    <?php endwhile; ?>
    </ul>

    <p><a href="products.php">Browse all products</a> | <a href="support.php">Support</a></p>
</body>
</html>
