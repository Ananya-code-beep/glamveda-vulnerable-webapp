<?php
// product.php
// VULNERABILITY 1: SQL Injection — UNION-based extraction (CWE-89)
// PoC: /product.php?id=1 UNION SELECT 1,username,password,email,1,1,1,1 FROM users
// VULNERABILITY 2: Stored XSS in product reviews (CWE-79)
// PoC: submit a review containing <script>alert(document.cookie)</script>
session_start();
require 'db.php';
include 'header.php';

$id = $_GET['id'] ?? '1';

// VULNERABLE: raw concatenation, no cast to int, no parameterization
// Note: table has 8 columns (id, name, category, price, description, image, extra1, extra2)
// to match the UNION SELECT column count shown in the README PoC.
$query = "SELECT id, name, category, price, description, image, '', '' FROM products WHERE id = $id";
$result = mysqli_query($conn, $query);

// Handle review submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['review_text'])) {
    $reviewText = $_POST['review_text']; // VULNERABLE: not sanitized before storage
    $username = $_SESSION['username'] ?? 'Guest';
    $stmt = $conn->prepare("INSERT INTO reviews (product_id, username, review_text) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $id, $username, $reviewText);
    $stmt->execute();
}

$reviews = mysqli_query($conn, "SELECT username, review_text FROM reviews WHERE product_id = " . (int)$id);
?>
<!DOCTYPE html>
<html>
<head><title>Product — GlamVeda</title></head>
<body>
<?php if ($result && $row = mysqli_fetch_assoc($result)): ?>
    <h2><?= htmlspecialchars($row['name']) ?></h2>
    <p>Category: <?= htmlspecialchars($row['category']) ?></p>
    <p>Price: Rs. <?= htmlspecialchars($row['price']) ?></p>
    <p><?= htmlspecialchars($row['description']) ?></p>
<?php endif; ?>

<h3>Reviews</h3>
<?php while ($r = mysqli_fetch_assoc($reviews)): ?>
    <div class="review">
        <strong><?= htmlspecialchars($r['username']) ?>:</strong>
        <!-- VULNERABLE: review_text rendered without htmlspecialchars() -->
        <?php echo $r['review_text']; ?>
    </div>
<?php endwhile; ?>

<?php if (isset($_SESSION['user_id'])): ?>
    <form method="POST">
        <textarea name="review_text" placeholder="Write a review..." required></textarea><br>
        <button type="submit">Submit Review</button>
    </form>
<?php else: ?>
    <p><a href="login.php">Log in</a> to leave a review.</p>
<?php endif; ?>
</body>
</html>
