<?php
// header.php — included at the top of most pages
// VULNERABILITY: this is the SINK for the stored XSS via username (register.php)
// The username is echoed unescaped here, so it fires site-wide once a malicious
// username has been registered and the victim (or admin) is logged in / viewing pages
// where session username is displayed.
?>
<div style="background:#f4f4f4;padding:10px;">
    <a href="index.php">GlamVeda</a> |
    <a href="products.php">Products</a> |
    <a href="search.php">Search</a> |
    <a href="contact.php">Contact</a> |
    <?php if (isset($_SESSION['username'])): ?>
        <!-- VULNERABLE: echoed without htmlspecialchars() -->
        Welcome, <?php echo $_SESSION['username']; ?> |
        <a href="profile.php">Profile</a> |
        <a href="order.php">My Orders</a> |
        <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
            <a href="admin/dashboard.php">Admin</a> |
        <?php endif; ?>
        <a href="logout.php">Logout</a>
    <?php else: ?>
        <a href="login.php">Login</a>
    <?php endif; ?>
</div>
