<?php
// contact.php
// VULNERABILITY: Stored XSS — contact message rendered unescaped in admin dashboard (CWE-79)
// PoC: submit message = <script>alert(document.cookie)</script>
// Higher-impact than the review XSS because it specifically targets the ADMIN's
// session when they view /admin/dashboard.php
session_start();
require 'db.php';
include 'header.php';

$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message']; // VULNERABLE: not sanitized before storage

    $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $message);
    $stmt->execute();
    $success = true;
}
?>
<!DOCTYPE html>
<html>
<head><title>Contact Us — GlamVeda</title></head>
<body>
    <h2>Contact Us</h2>
    <?php if ($success): ?><p>Thanks! We'll get back to you soon.</p><?php endif; ?>
    <form method="POST">
        <input type="text" name="name" placeholder="Your Name" required><br>
        <input type="email" name="email" placeholder="Your Email" required><br>
        <textarea name="message" placeholder="Your message..." required></textarea><br>
        <button type="submit">Send</button>
    </form>
</body>
</html>
