#!/bin/bash
# setup.sh — GlamVeda lab environment setup for Kali Linux
# FOR USE ONLY ON AN ISOLATED VM/NETWORK YOU CONTROL.

set -e

echo "=== GlamVeda Setup ==="
echo "This will install Apache, MariaDB, PHP, Node.js, and attempt MongoDB."
echo "Run this only on an isolated Kali VM with no internet-facing exposure."
read -p "Continue? (y/n) " confirm
if [ "$confirm" != "y" ]; then
    echo "Aborted."
    exit 1
fi

echo "[1/6] Updating package lists..."
sudo apt update

echo "[2/6] Installing Apache, MariaDB, PHP..."
sudo apt install -y apache2 mariadb-server php php-mysqli libapache2-mod-php

echo "[3/6] Installing Node.js and npm..."
sudo apt install -y nodejs npm

echo "[4/6] Attempting MongoDB install (Kali's default repos don't always have mongodb-org)..."
if ! sudo apt install -y mongodb; then
    echo ""
    echo "!! MongoDB package not found in default repos. Options:"
    echo "   1. Run MongoDB via Docker instead:"
    echo "      docker run -d -p 27017:27017 --name glamveda-mongo mongo:7"
    echo "   2. Install MongoDB on a separate Debian/Ubuntu VM and update"
    echo "      MONGO_URL in nosql-api/server.js to point to it."
    echo ""
fi

echo "[5/6] Setting up MySQL database..."
sudo mysql -u root < sql/schema.sql || mysql -u root -proot < sql/schema.sql

echo "[6/6] Deploying PHP app to /var/www/html/glamveda..."
sudo mkdir -p /var/www/html/glamveda
sudo cp -r main-site/* /var/www/html/glamveda/
sudo chown -R www-data:www-data /var/www/html/glamveda
sudo chmod -R 755 /var/www/html/glamveda

echo "Configuring Apache vhost with AllowOverride All (needed for uploads/.htaccess demo)..."
sudo tee /etc/apache2/sites-available/glamveda.conf > /dev/null <<EOF
<VirtualHost *:80>
    DocumentRoot /var/www/html/glamveda
    <Directory /var/www/html/glamveda>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
EOF

sudo a2ensite glamveda.conf
sudo a2enmod rewrite
sudo systemctl restart apache2
sudo systemctl restart mariadb

echo ""
echo "=== Setup complete ==="
echo "Main site: http://localhost/"
echo ""
echo "Now start the ticket microservice manually:"
echo "  cd nosql-api && npm install && node server.js"
echo ""
echo "Default accounts:"
echo "  admin / AdminP@ss123 (admin)"
echo "  priya / priya123 (customer)"
echo "  ananya / ananya123 (customer)"
echo "  testuser / password (customer)"
