// server.js — GlamVeda support ticket microservice
// VULNERABILITY: NoSQL Injection (CWE-943)
// PoC: POST /api/tickets/search with body:
//   {"email":{"$ne":null},"pin":{"$ne":null}}
// Because email/pin are passed straight into the MongoDB query without type
// checking, an attacker can submit MongoDB operators instead of literal strings,
// bypassing the intended email+PIN lookup entirely.

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { MongoClient } = require('mongodb');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const MONGO_URL = process.env.MONGO_URL || 'mongodb://localhost:27017';
const DB_NAME = 'glamveda_support';

let db;

async function connectDB() {
    const client = new MongoClient(MONGO_URL);
    await client.connect();
    db = client.db(DB_NAME);
    console.log('Connected to MongoDB:', DB_NAME);

    // Seed a couple of tickets if the collection is empty (fresh setup)
    const count = await db.collection('tickets').countDocuments();
    if (count === 0) {
        await db.collection('tickets').insertMany([
            { email: 'priya@example.com', pin: '4821', subject: 'Order delayed', status: 'open' },
            { email: 'ananya@example.com', pin: '7734', subject: 'Refund request', status: 'closed' },
        ]);
        console.log('Seeded sample tickets.');
    }
}

// VULNERABLE endpoint — no type validation on email/pin before querying
app.post('/api/tickets/search', async (req, res) => {
    const { email, pin } = req.body;

    try {
        // VULNERABLE: email and pin are passed directly into the query object.
        // If the client sends { "$ne": null } instead of a string, MongoDB treats
        // it as a real query operator, not a literal value.
        const ticket = await db.collection('tickets').findOne({ email, pin });

        if (ticket) {
            res.json({ found: true, ticket });
        } else {
            res.json({ found: false, message: 'No matching ticket found.' });
        }
    } catch (err) {
        res.status(500).json({ error: 'Server error', details: err.message });
    }
});

// Submit a new ticket (not directly part of the vulnerability, included for completeness)
app.post('/api/tickets/create', async (req, res) => {
    const { email, pin, subject } = req.body;
    if (typeof email !== 'string' || typeof pin !== 'string' || typeof subject !== 'string') {
        return res.status(400).json({ error: 'Invalid input' });
    }
    const result = await db.collection('tickets').insertOne({ email, pin, subject, status: 'open' });
    res.json({ success: true, id: result.insertedId });
});

const PORT = 5000;
connectDB().then(() => {
    app.listen(PORT, () => console.log(`GlamVeda ticket API running on port ${PORT}`));
}).catch(err => {
    console.error('Failed to connect to MongoDB:', err.message);
});
