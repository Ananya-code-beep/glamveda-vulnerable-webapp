# routes/

Currently all routes are defined directly in `server.js` for simplicity, since this
is a small single-purpose microservice (support ticket search + creation only).

If extended further, ticket routes would be split out here, e.g. `tickets.js`,
following standard Express router conventions:

```js
const router = require('express').Router();
router.post('/search', ...);
module.exports = router;
```
